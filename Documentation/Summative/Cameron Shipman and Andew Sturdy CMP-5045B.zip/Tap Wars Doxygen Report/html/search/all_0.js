var searchData=
[
  ['game_0',['Game',['../group___screens.html#ga416be25d217c06a6cb876ef3be3e95ca',1,'TapWars.c']]]
];

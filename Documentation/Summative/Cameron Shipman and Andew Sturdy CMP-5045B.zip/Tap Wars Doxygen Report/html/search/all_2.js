var searchData=
[
  ['periphral_0',['Periphral',['../group___screens.html#ga5d513f43e53baccc5b1c9dda46d7944c',1,'TapWars.c']]]
];

var searchData=
[
  ['winner_0',['Winner',['../group___screens.html#gaf58ce4bc09a8cc6977b585a1f58bbaca',1,'TapWars.c']]]
];

var searchData=
[
  ['screens_0',['Screens',['../group___screens.html',1,'']]],
  ['systemclock_5fconfig_1',['SystemClock_Config',['../group___m_a_i_n.html#ga70af21c671abfcc773614a9a4f63d920',1,'TapWars.c']]]
];

var searchData=
[
  ['main_0',['main',['../group___main___loop.html#ga840291bc02cba5474a4cb46a9b9566fe',1,'TapWars.c']]],
  ['mainmenu_1',['MainMenu',['../group___screens.html#gafd373b7346352fc367677280a339cf0a',1,'TapWars.c']]]
];
